#!/usr/bin/env python
import matplotlib
matplotlib.rcParams['legend.fancybox'] = True
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.mlab as mlab
from matplotlib import rc
rc('text', usetex=True)
rc('font', family='serif')
from pylab import *
from scipy import *
from scipy.optimize import leastsq
from scipy.optimize import fmin_slsqp
from scipy.optimize import curve_fit
from scipy.odr import *


dir_ang_I01 = np.loadtxt('dir_ang_I0.1.dat')
dir_ang_I1 = np.loadtxt('dir_ang_I1.dat')
dir_ang_I3 = np.loadtxt('dir_ang_I3.dat')
dir_ang_I10 = np.loadtxt('dir_ang_I10.dat')
dir_ang_I30 = np.loadtxt('dir_ang_I30.dat')

dir_ang_I01t = (dir_ang_I01[0:100]+dir_ang_I01[100:201])/2.
dir_ang_I01t = np.append(dir_ang_I01t,dir_ang_I01t,axis=0)
dir_ang_I01t[:,0] = dir_ang_I01[:,0]
dir_ang_I01t[:,1] = dir_ang_I01[:,1]

dir_ang_I1t = (dir_ang_I1[0:100]+dir_ang_I1[100:201])/2.
dir_ang_I1t = np.append(dir_ang_I1t,dir_ang_I1t,axis=0)
dir_ang_I1t[:,0] = dir_ang_I1[:,0]
dir_ang_I1t[:,1] = dir_ang_I1[:,1]

dir_ang_I3t = (dir_ang_I3[0:100]+dir_ang_I3[100:201])/2.
dir_ang_I3t = np.append(dir_ang_I3t,dir_ang_I3t,axis=0)
dir_ang_I3t[:,0] = dir_ang_I3[:,0]
dir_ang_I3t[:,1] = dir_ang_I3[:,1]

dir_ang_I10t = (dir_ang_I10[0:100]+dir_ang_I10[100:201])/2.
dir_ang_I10t = np.append(dir_ang_I10t,dir_ang_I10t,axis=0)
dir_ang_I10t[:,0] = dir_ang_I10[:,0]
dir_ang_I10t[:,1] = dir_ang_I10[:,1]

dir_ang_I30t = (dir_ang_I30[0:100]+dir_ang_I30[100:201])/2.
dir_ang_I30t = np.append(dir_ang_I30t,dir_ang_I30t,axis=0)
dir_ang_I30t[:,0] = dir_ang_I30[:,0]
dir_ang_I30t[:,1] = dir_ang_I30[:,1]

figure(figsize=(3.375,3.375),dpi=1200)  # One column figure
color = '0.75'
test = plt.subplot(111)
#test.set_xscale('log')

#plt.plot(dir_ang_I1[:,1],dir_ang_I1[:,2])
#plt.plot(dir_ang_I1t[:,1],dir_ang_I1t[:,2])
#plt.plot(180.-dir_ang_I1[:,1],dir_ang_I1[:,2])
plt.plot(180.-dir_ang_I01t[:,1],dir_ang_I01t[:,2],label=r'$I=0.001$')
plt.plot(180.-dir_ang_I1t[:,1],dir_ang_I1t[:,2],label=r'$I=0.01$')
plt.plot(180.-dir_ang_I3t[:,1],dir_ang_I3t[:,2],label=r'$I=0.03$')
plt.plot(180.-dir_ang_I10t[:,1],dir_ang_I10t[:,2],label=r'$I=0.1$')
plt.plot(180.-dir_ang_I30t[:,1],dir_ang_I30t[:,2],label=r'$I=0.3$')


plt.ylabel(r"$\mathcal{P}(\theta^\circ)$",fontsize='12')
plt.xlabel(r"$\theta^\circ$",fontsize='12')


#plt.ylim([0.4,1.2])
plt.xlim([-90,90])

import matplotlib.font_manager 
prop = matplotlib.font_manager.FontProperties(size=8) 

props = dict(boxstyle='round', facecolor='wheat', alpha=0.5)
test.text(0.08, 0.5,r'$\alpha=3$'+'\n'+'$\mu_p=0$'+'\n'+'inertial', transform=test.transAxes, fontsize=12,verticalalignment='top', bbox=props)

mpl.rcParams['legend.framealpha'] = None
mpl.rcParams['legend.edgecolor'] = 'inherit'
test.legend(shadow=True, fancybox=True,loc=2,ncol=1,prop=prop)

#inset=plt.axes([0.25,0.35,0.35,0.35])
#inset.set_xscale('log')
#plt.ylim([-0.01,0.01])
#plt.xlim([1e-5,1e0])
#plt.ylabel(r"$\delta \phi$",fontsize='15')
#plt.xlabel(r"$J+\alpha I$ ",fontsize='15')

plt.subplots_adjust(left=0.19)
plt.subplots_adjust(right=0.96)
plt.subplots_adjust(bottom=0.18)
plt.subplots_adjust(top=0.98)
plt.savefig('Ang_Alpha3_vs_I.pdf')
